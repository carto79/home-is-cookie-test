import sharp from 'sharp';
const folder='/workspace/scratch/28cc600c769f/cookie-media/';
const files=['IMG_4419.jpg','IMG_4730.jpg','IMG_4545.jpg','IMG_5400.jpg','IMG_5399.jpg','IMG_5670.JPG','IMG_5748.JPG','IMG_5835.jpg','IMG_5659.JPG','IMG_6503.JPEG'];
for(let i=0;i<files.length;i++)await sharp(folder+files[i],{failOn:'none'}).rotate().resize({width:1200,height:1200,fit:'inside',withoutEnlargement:true}).webp({quality:86}).toFile(`public/assets/gallery-${i+1}.webp`);
const hero='/workspace/scratch/28cc600c769f/upload/0 IMG_4239.jpeg';
await sharp(hero).rotate().resize({width:1600,withoutEnlargement:true}).webp({quality:88}).toFile('public/assets/hero-batch.webp');
await sharp(hero).rotate().resize({width:640}).webp({quality:85}).toFile('public/assets/hero-batch-640.webp');
