# Home is Cookie — framework prototype

Astro static website based directly on the uploaded index(4).html design and Home_is_Cookie_Website_Framework.md. Source is separate from the live carto79 repository and Cloudflare account. No DNS changes have been made.

## Develop and build

`npm ci` then `npm run dev` locally. `npm run build` generates `dist/`.

Cloudflare Pages: framework Astro, build `npm run build`, output `dist`. The current `exit 0` and `/` settings for the old HTML site must change if this source is adopted. Upload the built dist contents for a direct static deployment instead.

All builds default to noindex. Set PUBLIC_SITE_LAUNCH=true only after launch acceptance. Merge existing robots crawler preferences, particularly GPTBot, before production; no prior preference has been assumed. Verify Cloudflare WAF, bot preferences, and OAI-SearchBot separately. Preserve email DNS records and review canonical redirects.

## Data and assets

`src/data/site.js` contains public business data, prices, FAQs, and gallery metadata. Update it and corresponding presentation copy together. The price workbook is not automatically synced. Original user files remain untouched. Actual uploaded photography is used; no synthetic customer images, review content, or portrait is included. Box contents are readable HTML alongside the original flyer illustration. Cormorant Garamond, Plus Jakarta Sans, and JetBrains Mono are self-hosted, subset Google Fonts. See docs/FONT-LICENSES.md.

## Connections

Jotform and Kit hosted links are real supplied destinations, but their account state and submissions are unverified. Copyable order summaries are advisory; browser/query-string totals never authorize payment. No payment endpoint, secret, receipt simulation, auto-enrollment, fake subscription success, or customer data storage is included. No live form or campaign was modified.

## Outstanding

See `/prototype-notes/` for remaining business decisions. Nine gallery photographs are included. Six public review excerpts were verified on Facebook and Google Maps and appear in the carousel. This is curated content, not a live-synced review feed. Policy pages are draft. Final Jotform reconciliation and payment testing are separate from this frontend. No analytics tags or verification records installed. Source-based tests cover local paths, metadata, schema parsing and price minimums; browser checks recorded in docs/QA.md.

## Original-design revision

The uploaded HTML is archived unchanged in original/index-original.html. Its stylesheet is preserved byte for byte in src/styles/original.css; responsive and new component additions live in extensions.css. See docs/IMPLEMENTATION-STATUS.md and docs/SETUP-GUIDE.md. The reusable source ZIP is in public/downloads.
