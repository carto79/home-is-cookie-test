# Home is Cookie — owner setup and launch guide

This is configuration guidance, not evidence that any account has been changed.

## Cloudflare deployment

Use the existing separate Home is Cookie Pages project. For this Astro source, set build command `npm run build` and output directory `dist`; use `npm ci` for reproducible local installation. The earlier `exit 0` and `/` settings apply only to the original buildless HTML site. Alternatively upload the compiled static package contents with index.html at its root. Domain settings, email DNS records, and taittfin.net remain separate.

Default builds are noindex previews. After approving content and reconciling integrations, enable `PUBLIC_SITE_LAUNCH=true` in production only. Rebuild. Verify HTTPS www canonical, apex redirect, removal of obsolete Canva forwarding, 200 responses, sitemap, robots, and Cloudflare security rules. OAI-SearchBot must be allowed at both robots and WAF layers. Preserve any existing GPTBot training preference. Do not assume a robots file overrides WAF blocks.

## 9. Jotform, Square, and the order paper trail

Existing order entry: `https://pci.jotform.com/form/231086273990158`.

**Requested architecture:** branded website → Jotform request → operator approval → Jotform payment processed by Square → reconciled order record → fulfillment. Corporate requests never collect a payment before approval. Proposed default is approval before payment for all orders, since dates/delivery require confirmation; ordinary retail can become immediate only after availability and fees are reliable.

Jotform’s Square integration supports product payments, user-defined amounts, customer-email mapping, and Square receipts [12]. That does not establish a secure, automatic quote/deposit/balance ledger. Authorization-only is not the same as collecting a 50% deposit. Prove the exact deposit calculation/payment setup in a duplicate test form before enabling it live.

**Request form:** concise stepped sections for product/quantity, requested date, pickup/delivery, contact, applicable artwork, policy acknowledgement. Required and optional fields clearly labeled. Present errors beside the field and in a summary; preserve input after failure. The submit button reads **Send order request**, not “Pay” when no money is collected. Confirmation: “We’ve received your request. Your order is not confirmed until we approve the details and the required payment is received.”

**Approval:** operator checks capacity, lead time, delivery address/fee, artwork suitability, product configurations, total, and balance due date. Save an immutable quote revision. A changed price or scope requires a new customer-approved revision; do not overwrite the accepted record.

**Payment:** approved customer sees itemized total and options for 50% deposit or full payment. The 50% refers to the final approved total, with any owner-approved tax/delivery treatment explicitly documented. The remaining balance and due date appear before commitment. Do not infer that an entire full payment is non-refundable simply because the deposit is non-refundable. Record acceptance of the displayed terms and version.

Use integer cents. Example: 10 Classic boxes = $130 merchandise, deposit $65 before any approved delivery/tax additions. If final total is $150, a 50% deposit is $75. An odd-cent total needs a documented rounding rule; proposed rule: deposit rounds up to the nearest cent, balance is exact total minus captured payments. Never double-round each line independently in conflicting systems.

**Payment integrity gate:** client-editable hidden fields, query strings, and readonly browser inputs are not trusted prices or proof of approval. Bind the request ID, quote revision, expected amount, and payment choice in a trusted configuration/backend or validated provider mechanism. A successful thank-you page is not evidence of payment. Confirm Square’s completed/captured payment status and reconcile currency/amount before marking the order reserved.

**Launch fallback if Jotform cannot enforce this:** retain Jotform intake and the paper trail, and use Square Invoices for the approved 50% deposit and balance. Square documents deposit schedules [13]. This is a fallback to review with Jason during integration, not an unannounced switch from his preferred Jotform payment experience. Do not invent native support to avoid discussing a real limitation.

**Minimum order record:** internal order ID; request submission ID; product IDs/quantities; price-list version; quote revision; requested and confirmed dates; private fulfillment details; approved subtotal/tax/delivery/total; deposit required; provider payment/receipt IDs; captured amounts; refunds; balance; terms acceptance; artwork approval; payment and fulfillment statuses; timestamps and operator notes. Keep card details inside Square’s payment flow.

State sequence: Requested → In review → Quote sent → Approved / awaiting payment → Deposit paid or Paid in full → Scheduled → Ready → Fulfilled. Keep payment status independent of fulfillment status. Rejected, canceled, expired quote, failed payment, and refunded states need explicit handling. Payment failure keeps the request and offers a retry; it never confirms the booking.

Duplicate payment notifications must be idempotent. Verify provider events using the current supported mechanism; reconcile missing events. Never infer Square inventory, catalog, invoice, and Jotform status are automatically synchronized by connecting the payment gateway. Start with a documented operator reconciliation procedure; add reliable automation afterward.

**Paper trail outputs:** request acknowledgement, approved quote, terms acceptance, payment receipt, outstanding-balance notice, and fulfillment confirmation all carry the same order reference. Generate PDF order/quote records where configured; Jotform supports invoice PDFs for eligible payment forms [14]. Do not equate a form-generated PDF with a settled Square payment.

## 10. Kit and customer follow-up

Existing signup destination: `https://home-is-cookie.kit.com/5d7463e261`.

Use the real Kit signup form or tested embed with a working hosted-link fallback. A custom visual form must not show a success state without a successful provider submission. Collect email; first name and interests are optional. Suggested interests: Cookies & sharing trays, Corporate gifts, Sun City Center delivery. Do not infer a subscriber’s address or age.

Marketing consent is separate from requesting or paying for an order. Do not auto-enroll all Jotform customers. When consent is given, record its source, timestamp, and wording, then deduplicate by email and apply an appropriate tag. Do not reactivate unsubscribed contacts through an order update.

Build a three-email welcome sequence triggered by confirmed signup. Kit documents connecting signup forms to sequences with Visual Automations; confirm the account’s plan supports the required configuration [15].

**Email 1 — immediately after confirmed signup.** Subject: “Welcome to Home is Cookie.” Body: “I’m LaTasha. I started baking with my grandmother, and her chocolate cookie recipe became the starting point for Home is Cookie. Everything we make is from scratch and baked to order. I’ll share new flavors, seasonal ordering dates, and ideas for bringing something homemade to your table.” CTA: **Explore the cookies**.

**Email 2 — two days later.** Subject: “Something for your next get-together.” Body: “Coffee with friends, visiting family, or a table that needs something sweet: a cookie tray makes sharing simple. Our Three-Dozen Tray includes 36 cookies for $50. Prefer a filled cookie? Stuffed cookies are $5 each, with a minimum of six. Send your requested date and we’ll confirm the details.” CTA: **Plan an order**. Pull prices from the approved content source when maintaining emails.

**Email 3 — five days after signup.** Subject: “A thank-you with your name on it.” Body: “For clients, colleagues, or an event, we make corporate cookie boxes and printed logo or photo cookies. Boxes start at $10 each with a 10-box minimum; printed cookies are $5 each with a 12-cookie minimum. Please allow at least two weeks for corporate orders.” CTA: **Explore corporate gifts**. For Sun City Center-only interest, substitute local delivery/hosting content rather than force corporate messaging.

Suppress inappropriate first-order reminders once an order is underway where reliable integration permits it. Fulfillment messages and review requests are operationally distinct from the welcome series; do not send them from an unverified purchase event. No automated emails are sent as part of this framework deliverable.



## 11. Reviews and reputation

Facebook reviews cannot be imported as customer-authored Google reviews. Customers need to leave their own Google reviews. Google may independently show third-party reviews, but the business cannot choose which source appears [16].

For the website, display real approved Facebook and Google excerpts with source links and accurate attribution. Obtain the review text and permission/use basis before publishing. Preserve meaning; label excerpts. No invented stars, reviewer photos, totals, or merged platform ratings. If a live feed is used, follow the provider’s attribution, caching, and display requirements and measure its performance cost. A small permissioned editorial selection is the simpler launch option.

Build the bottom-of-page scrolling strip as specified in the motion table. The gallery and review components are separate: customer photos do not require a positive review, and permission to display a photo is not permission to reuse a testimonial.

Do not mark business-controlled testimonials as an Organization/LocalBusiness `AggregateRating` to seek Google stars. Google restricts self-serving review rich results [17]. Product ratings also cannot be fabricated or populated from unrelated business reviews.

**Review growth workflow:** use Business Profile → Read reviews → Get more reviews to copy the actual review-request link and download the provided QR code [18]. Verify that it opens the correct profile. The supplied Maps URL identifies the intended business but was not readable in this research pass; its coordinates must not be copied into site schema or treated as a confirmed physical address.

Proposed timing: request an honest review 24–48 hours after fulfilled delivery/pickup, with an order-status check before sending. Apply consistently rather than sending only to people who first report satisfaction. Do not offer discounts, cookies, or rewards in return for reviews [19].

Suggested request: “Thank you for ordering from Home is Cookie. If you have a moment, would you share an honest Google review of your experience? Your feedback helps other local customers find us.” CTA **Leave a Google review**. A packaging insert can use the same verified QR code and wording. Do not publish a guessed review-write URL.



## 15. Analytics and owner setup instructions

Use owner-controlled accounts and record configuration IDs, not secrets, in deployment configuration. Analytics setup can follow the live domain cutover; Search Console DNS verification can be prepared beforehand. Do not claim existing properties were checked or configured.

**Google Search Console** [27]:

1. Open `https://search.google.com/search-console/` using the business owner’s Google account.
2. Add a Domain property for `homeiscookie.com` so it covers www and apex versions.
3. Copy the exact DNS TXT verification record Google supplies into the domain’s DNS provider. Preserve existing mail/security records; return and verify.
4. Once live, submit `https://www.homeiscookie.com/sitemap.xml` under Sitemaps.
5. Inspect the homepage, corporate page, and Sun City Center page. Test the live URL, confirm canonical/indexability, and request indexing where appropriate.
6. Review indexing, search queries, clicks, and page performance. Keep the verification record in DNS.

**Google Analytics 4** [28]:

1. Open `https://analytics.google.com/`; create or use the business account and create a Home is Cookie property.
2. Set reporting time zone to New York/Eastern and currency to USD. Add the live HTTPS site as a Web data stream.
3. Install its Google tag once through the site layout or an existing tag manager, not both. Configure consent behavior to match actual data practices.
4. Verify a test visit in Realtime/DebugView. Keep form contact details, artwork URLs, private order data, and payment data out of analytics.
5. Configure the events below. Jotform/Square are external domains; attribution and completed-order events require a tested integration, not an assumption that a click can be followed automatically.

**Bing Webmaster Tools** [29]:

1. Open `https://www.bing.com/webmasters/` with an owner-controlled account.
2. Import the verified site from Search Console, or add it and complete the displayed verification method.
3. Confirm sitemap submission and inspect priority URLs.
4. Monitor crawl/indexing issues and available search/AI performance reports. Access and reporting availability must be checked in the actual account.

| Event | When it fires | What it means |
|---|---|---|
| `order_click` | Visitor enters Jotform/order route | Intent, not a sale |
| `corporate_quote_click` | Visitor starts corporate request | Intent, not a submitted lead |
| `order_request_submitted` | Verified successful Jotform submission | An actual request |
| `quote_approved` | Recorded approval | Accepted opportunity, not payment |
| `deposit_paid` | Verified reconciled captured payment | Reservation deposit, not full order revenue |
| `order_paid_in_full` | Verified balance reaches zero | Fully paid order; deduplicate by order ID |
| `order_fulfilled` | Operator confirms pickup/delivery | Fulfillment, separate from payment |
| `newsletter_signup_confirmed` | Verified Kit confirmation/integration | Subscriber, not merely a button click |
| `review_link_click` | Review destination opened | Invitation engagement, not a posted review |

For accounting and commercial reporting, retain order value, cash collected, refunds, and outstanding balance separately. If a GA4 `purchase` event is used, define one consistent recognition point and fire once per transaction; do not count both deposit and full order value as separate full purchases. Compare actual payment totals with Square records. Analytics is not the accounting ledger.

Dashboard: approved-order value and average merchandise order value; percentage of paid orders at/above $40; corporate quote-to-order conversion; Sun City Center requests/paid orders identified from actual submitted delivery area; form completion; repeat customers; confirmed subscribers; reviews requested and actual new Google reviews. GA geolocation is not a reliable substitute for a submitted delivery ZIP.



## Source documentation

- https://developers.cloudflare.com/pages/framework-guides/deploy-an-astro-site/
- https://support.google.com/webmasters/answer/9008080
- https://support.google.com/analytics/answer/9304153
- https://www.bing.com/webmasters/help/add-and-verify-site-12184f8b
- https://developers.openai.com/api/docs/bots
- https://support.google.com/business/answer/3474122
