# Prototype verification

- Astro static build passed; 15 HTML pages including owner notes and 404.
- Local HTML check: all local image, link, script and stylesheet targets resolve; each page has one H1; JSON-LD parses; preview pages are noindex.
- First-party compressed JS approximately 2 KB; CSS approximately 5 KB, excluding assets. These are bundle sizes, not field Core Web Vitals.
- Desktop homepage visually reviewed in Chrome.
- Responsive iframe review at 390 and 320 CSS pixels (375 / 305 content width with browser scrollbar): no horizontal document overflow on homepage and corporate page. Mobile menu opens, Escape closes, focus returns to the trigger. Mobile header has a direct ordering link.
- Estimator: 9 boxes gives an error; 20 Classic boxes shows $260; continuing retains 20 Classic boxes, 1 stuffed + 6 mini contents, and $260 in request summary.
- Gallery: Stuffed filter shows two photos; dialog opens; Next changes photo/caption; Escape closes.
- Native dialogs provide focus containment; explicit focus styling and reduced-motion CSS implemented. Full assistive-technology and WCAG audit not performed.
- Dev-only Astro toolbar emitted HMR errors during config restart; toolbar disabled. These files are not in static output.
- External Jotform / Kit links match supplied URLs. No real submission, campaign, charge, deposit, receipt, or provider API verification performed.
- Customer photos, review excerpts, review-request link, and exact box photos are not fabricated; final assets/content remain pending.
- Social metadata uses production canonical domain for eventual deployment. Public-domain bot/WAF access and search indexing are not verified by this private prototype.

## Original-design revision — 24 October 2026

- Uploaded index(4).html archived unchanged; original CSS matches byte for byte.
- Astro build passes: 16 HTML pages. Every page has one H1 and unique title/description; all JSON-LD parses; all local asset/navigation targets resolve.
- First-party compressed assets: about 7 KB CSS and 2.4 KB JS; third-party hosted forms remain external links.
- Browser visual checks: desktop homepage and 390/320 px iframe layouts. Measured document widths 375/305 px (excluding browser scrollbar), with no horizontal overflow.
- Mobile menu opens, Escape closes, and focus returns to Menu. Corporate estimate: 20 Classic boxes = $260; quantity 9 produces the minimum error.
- Gallery filtering shows two stuffed-cookie photographs; lightbox opens, Escape closes, and focus returns to its trigger.
- No application console errors observed; browser-extension metadata errors are outside the site.
- Payment/account actions, provider signup confirmation, multi-review animation with future content, a full accessibility audit, real-device performance, and live domain/crawler checks remain launch validation tasks. No test purchase or customer message was sent.

## Photo, minimum, contact and carousel update — 23 October 2026
- Main hero uses owner-uploaded IMG_4239, optimized as responsive WebP.
- Ten distinct Drive photographs inspected; two incomplete cached originals were downloaded again and checked after conversion.
- Six authentic review excerpts: four Facebook recommendations and two Google reviews. No duplicate reviewers, simulated ratings, or live-sync claim.
- Desktop manual Next advances the track; interaction pauses automatic movement and changes the control to Play carousel.
- Phone removed from rendered links and Organization schema; the former everyday order URL falls back to a sharing tray. Printed-cookie minimum remains 12; stuffed and sandwich cookie minimums are six.

## Menu and gallery revision — 2026-10-24
- Production build passes (17 pages).
- Generated pages checked for local image/link resolution, valid JSON-LD, one H1, current prices, four menu cards in the requested order, and six replacement photos within the ten-photo gallery.
- Executed order-summary script with six/twelve stuffed and sandwich cookies: $30/$60; below-minimum sandwich requests fall back to six.
- Browser preview QA could not finish: the connected browser timed out twice. Responsive visual appearance of this revision is therefore unverified; original layout/CSS retained.

## Mobile revision — browser verified

- Homepage inspected in frames sized 320, 375, 390, 430 and 768 CSS pixels. Document width never exceeded the available content viewport (the browser's vertical scrollbar occupies 15 px).
- Gallery, corporate gifts, order and sandwich-cookie pages checked at frame width 320; no horizontal document overflow.
- Mobile menu opens; order link destinations checked in rendered DOM. Header and hero point directly at the supplied PCI Jotform URL.
- Social controls have accessible names. Google listing and its Write a review entry point were visible in browser; a one-click review composer URL has not been supplied.
